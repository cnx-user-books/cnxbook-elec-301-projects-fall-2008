function [y,W] = stfical(v,L,numiter);

L = L + rem((L+1),2);
[m,N] = size(v);
W = kron(eye(m),[zeros((L-1)/2,1);1;zeros((L-1)/2,1)]);
V = zeros(m*L,N);
for i=1:m
    V((i-1)*L+1:i*L,:) = toeplitz([v(i,1);zeros(L-1,1)],v(i,:));
end
y = zeros(m,N);
for i=1:m
    Wold = zeros(m*L,1);
    k = 0;
    y(i,:) = W(:,i)'*V;
    crit = 1;
    while (crit*(k<numiter))
        Wold = W(:,i);
        k = k+1;
        f = y(i,:)'.^3;
        fp = 3*sum(y(i,:).^2);
        W(:,i) = V*f - fp*W(:,i);
        W(:,i) = orthW(W(:,1:i),m,L,10);
        y(i,:) = W(:,i)'*V;
        crit = (abs(abs(W(:,i)'*Wold)-1)>0.0001);
    end
end