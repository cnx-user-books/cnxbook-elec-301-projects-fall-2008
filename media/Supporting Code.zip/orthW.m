function [Wi] = orthW(W,m,L,numorth);

i = size(W,2);
Wi = W(:,i)/norm(W(:,i));
for k=1:numorth
    Wt = zeros(m*L,1);
    for j=1:i-1
        Wt = Wt + gfun(Wi,W(:,j),m,L);
    end
    Wi = 3/2*Wi - 1/2*gfun(Wi,Wi,m,L) - Wt;
end