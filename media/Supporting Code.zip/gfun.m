function [G,C] = gfun(U,V,m,L);

Wi = zeros(L,m);
Wi(:) = U;
Wj = zeros(L,m);
Wj(:) = V;
Ct = zeros((3*L-1)/2,1);
Z = zeros((L-1)/2,1);
ll = (L+1)/2:(3*L-1)/2;
llr = L:-1:1;
for i=1:m
    Ct = Ct + filter(Wi(llr,i),1,[Wj(:,i);Z]);
end
C = Ct(ll);
Gt = filter(C(llr),1,[Wj;zeros((L-1)/2,m)]);
Gt = Gt(ll,:);
G = Gt(:);